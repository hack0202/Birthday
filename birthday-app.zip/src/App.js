import React, { useState } from 'react';
import './styles.css';

function App() {
  const [showMessage, setShowMessage] = useState(false);

  return (
    <div className="container">
      <h1 className="animated-text">Happy Birthday, darling ❤️</h1>
      <p className="animated-text delay-1">
        I just want you to be happy, stay healthy and see every dream of yours come true.
      </p>
      <p className="animated-text delay-2">
        Keep shining, and never stop smiling. I’m always with you.
      </p>
      <p className="animated-text delay-3">Love you so much 💖</p>
      <button className="btn" onClick={() => setShowMessage(true)}>Click Me</button>
      {showMessage && <p className="host-msg">Host this on a free domain like Netlify and share it with your love! 💌</p>}
    </div>
  );
}

export default App;
